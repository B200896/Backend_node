import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate, Link } from 'react-router-dom';

export function Tableedit() {
    const { id } = useParams();
    const [values, setValues] = useState({
        name: '',
        description: ''
    });
    const navigate = useNavigate();

    useEffect(() => {
        axios.get(`http://localhost:4000/categoriesEdit/${id}`)
            .then(res => {
                console.log(res);
                setValues({ name: res.data.response.name, description: res.data.response.description });
            })
            .catch((err) => console.log(err));
    }, [id]);

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.put(`http://localhost:4000/CategoriesUpdate/${id}`, values)
            .then(() => {
                navigate('/');
            })
            .catch(err => console.log(err));
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label htmlFor="name">Name:</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value={values.name}
                    onChange={e => setValues({ ...values, name: e.target.value })}
                    required
                />
            </div>
            <div>
                <label htmlFor="description">Description:</label>
                <input
                    type="text"
                    id="description"
                    name="description"
                    value={values.description}
                    onChange={e => setValues({ ...values, description: e.target.value })}
                    required
                />
            </div>
            <Link to="/data">
            <button type="submit">Update</button>
            </Link>
        </form>
    );
}
