import { useState } from 'react'
import { Register } from "./Register";
import { Login } from './Login';
import { Home } from './Home'
import { Homedetails } from './Homedetails';
import { ToastContainer } from 'react-toastify';
import { Formedit } from './Formedit';
// import Categories from './Categories';
import Table from './Table';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import PrivateRoute from './privateroute';
import { Tabledetails } from './Tabledetails';
import { Tableedit } from './Tableedit';
import { Brand } from './Brands/Brands';
function App() {


  return (
    <>
     
      <Router>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                {/* <Router path="/data" element={<Categories />} /> */}
                <Route path='/category/add' element={<Table/>} /> 
                <Route element={<PrivateRoute />}>
                    <Route path="/home" element={<Homedetails />} />
                </Route>
                <Route path='/category/edit/:id' element={<Tableedit/>} />
                <Route path="/" element={<Home />} /> 
                <Route path="/user"element={<Homedetails/>} />
                <Route path='/data'element={<Tabledetails/>} />
                <Route path='/brand'element={<Brand/>} />

                
            </Routes>
      </Router>
      
     
    </>

  )
}

export default App
