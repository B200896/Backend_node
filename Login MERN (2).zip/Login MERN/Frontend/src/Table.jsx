import { useEffect } from "react";
import React, { useState } from 'react';
import axios from 'axios';
const Table = () => {

    
    const[name,setName]=useState('');
    const[description,setDescription]=useState('');
    const handleSubmit =  async (event)=>{
      event.preventDefault();
      try {
        const response=await axios.post("http://localhost:4000/Categories",{
          name,
          description,
      }
      )}
      catch(error){
        console.log(error);

      }
    
    }   
  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label htmlFor="name">Name:</label>
        <input type="text" id="name" name="name" value={name} onChange={(e) => setName(e.target.value)} required />
      </div>
      <div>
        <label htmlFor="price">Description:</label>
        <input type="text" id="description" name="description" value={description} onChange={(e) => setDescription(e.target.value)} required />
      </div>
      
      <button type="submit">Submit</button>
    </form>
  );
}

export default Table;