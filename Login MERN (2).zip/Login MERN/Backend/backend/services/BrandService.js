const Brand=require('../models/brands')
const BrandServiceAdd = async(req,res) =>{
    const{ name,description} = req.body;
    try{
        if(!name || !description){
            return res.status(400).json({success: false, msg:"Enter the required field"});

        }
        const newBrand = new Brand({
            name,
            description,
        });
        await newBrand.save();
        return res.status(201).json({success: true, msg:"Details saved successfully"})
    }
    catch (error) {
        console.log('Error',error);
        return res.status
    }
}
module.exports={BrandServiceAdd}