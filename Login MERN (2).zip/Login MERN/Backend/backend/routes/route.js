const express = require('express')
const router=express.Router();
const userController=require('../controller/userController');
const user = require('../models/user');
const categoriesController=require('../controller/categoriesController')
const category = require('../models/categories')
const brandController=require('../controller/BrandController')
const brand = require('../models/brands')


router.route('/register').post(userController.userRegister);
router.route('/Login').post(userController.userLogin);
router.route('/UserData').get(userController.userDataController);
router.route('/UserDelete/:id').delete(userController.userDataDelete);
router.route('/Useredit/:id').get(userController.userDataEdit);
router.route('/UserActive/:id').post(userController.userDataActive);
router.route('/Categories').post(categoriesController.Categories);
router.route('/CategoriesData').get(categoriesController.categoriesDataController);
router.route('/CategoriesDelete/:id').delete(categoriesController.categoriesDeleteController);
router.route('/CategoriesEdit/:id').get(categoriesController.categoriesEditController);
router.route('/CategoriesUpdate/:id').put(categoriesController.categoriesUpdateController);
router.route('/Brands').post(brandController.brandsDataController);




















module.exports=router;