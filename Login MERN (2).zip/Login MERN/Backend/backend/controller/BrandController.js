const userBrand=require('../services/BrandService')
const brandsDataController= (req,res)=>{
    userBrand.BrandServiceAdd(req,res)
}
module.exports={brandsDataController};