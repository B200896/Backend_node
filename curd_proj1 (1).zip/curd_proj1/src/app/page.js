import Login from "./Components/Login";

export default function Home() {
  return (
     
    <>
    <Login />
    </>
  );
}
