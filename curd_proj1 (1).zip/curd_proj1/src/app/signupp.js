import SignupForm from "../components/SignupForm";

export default function Signup() {
  return (
    <div>
      <SignupForm />
    </div>
  );
}