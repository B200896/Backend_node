import react from 'react';
import React,{useState,useEffect} from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
export function Products(){
    const [name,setName] = useState('');
    const [description,setDescription] = useState('');
    const [price,setPrice]=useState('');
    const [model,setModel]=useState('');
    const [brandid,setBrandid]=useState('');
    const[brands,setBrands] = useState([]);
    const [subcategoryid,setsubcategoryid]=useState('');
    useEffect(() => {
      axios.get("http://localhost:4000/BrandData")
      .then(response => setBrands(response.data))
      .catch(error => console.log('Error fetching brands'))
    },[]);
    const navigate = useNavigate();
    const handleSubmit =  async (event)=>{
        event.preventDefault();
        
        try {
          const response=await axios.post("http://localhost:4000/Products",{

            name,
            description,
            price,
            model,
            brandid,
            subcategoryid
           

        }
        ); navigate ('/productdata') }
       
        catch(error){
          console.log(error);
  
        }
    } 
    

    return(
        <form onSubmit={handleSubmit}>
        <div>
            <h1>Product Details Section</h1>
          <label htmlFor="name">Name:</label>
          <input type="text" id="name" name="name" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div>
          <label htmlFor="description">Description:</label>
          <input type="text" id="description" name="description" value={description} onChange={(e) => setDescription(e.target.value)} required />
        </div>
        <div>
          <label htmlFor="price">Price:</label>
          <input type="text" id="price" name="price" value={price} onChange={(e) => setPrice(e.target.value)} required />
        </div>
        <div>
          <label htmlFor="model">Model:</label>
          <input type="text" id="model" name="model" value={model} onChange={(e) => setModel(e.target.value)} required />
        </div>
        {/* <div> */}
          <label htmlFor="price">Brand:</label>

          <select type="text" id="brandid" name="brandid" value={brandid} onChange={(e) => setBrandid(e.target.value)} required >
            <option value=""></option>
            {
              brands.map((bran) =>(
                <option key={bran._id} value={bran.name}>
                  {bran.name}
                </option>
              ))
            }
            </select>
        {/* </div> */}
        <div>
          <label htmlFor="subcategory">Subcategory:</label>
          <input type="text" id="subcategoryid" name="subcategoryid" value={subcategoryid} onChange={(e) => setsubcategoryid(e.target.value)} required />
        </div> 
              
        <button type="submit">Submit</button>
      </form>

    )


}