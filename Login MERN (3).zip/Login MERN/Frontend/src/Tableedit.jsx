import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate, Link } from 'react-router-dom';

export function Tableedit() {
    const { id } = useParams();
    const [values, setValues] = useState({
        name: '',
        description: ''
    });
    const navigate = useNavigate();

    useEffect(() => {
        axios.get(`http://localhost:4000/categoriesEdit/${id}`)
            .then(res => {
                console.log(res);
                setValues({ name: res.data.response.name, description: res.data.response.description });
            })
            .catch((err) => console.log(err));
    }, [id]);

    const handleSubmit = (e) => {
        e.preventDefault();
        // console.log("cliack")
        axios.put(`http://localhost:4000/CategoriesUpdate/${id}`, values)
            .then((res) => {
                navigate('/data')
                console.log("res",res)
               
            })
            .catch(err => console.log(err));
    };

    return (
        <form onSubmit={handleSubmit}>
            
                <label htmlFor="name">Name:</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value={values.name}
                    onChange={e => setValues({ ...values, name: e.target.value })}
                    required
                />
          
                <label htmlFor="description">Description:</label>
                <input
                    type="text"
                    id="description"
                    name="description"
                    value={values.description}
                    onChange={e => setValues({ ...values, description: e.target.value })}
                    required
                />
          
            
            <button type="Submit">Update</button>
            
        </form>
    );
}
