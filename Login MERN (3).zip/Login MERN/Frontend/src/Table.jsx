import { useEffect } from "react";
import React, { useState } from 'react';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
const Table = () => {

    
    const[name,setName]=useState('');
    const[description,setDescription]=useState('');
    const[file,setFile]=useState('');
    const navigate= useNavigate();
    const handleSubmit =  async (event)=>{
      event.preventDefault();
      try {
        const response=await axios.post("http://localhost:4000/Categories",{

          name,
          description,
          image
          
      },
      {
        header:{
          'Content-Type':'multipart/form-data',
           
        },

      }
      
      ); navigate('/categoriesdata')}
      catch(error){
        console.log(error);

      }
    
    }
    const handleFileChange = (event) => {
      
      setFile(event.target.files[0]);
    };
    const handleUpload = async() =>{
      const formData=new FormData();
      formData.append('image',file);
    }
  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label htmlFor="name">Name:</label>
        <input type="text" id="name" name="name" value={name} onChange={(e) => setName(e.target.value)} required />
      </div>
      <div>
        <label htmlFor="price">Description:</label>
        <input type="text" id="description" name="description" value={description} onChange={(e) => setDescription(e.target.value)} required />
      </div>
      <div>
      <label htmlFor="file">Upload File:</label>
      <input type="file" id="file" name="file" value={file} onChange={handleFileChange}required/>
      <button type="button" onClick={handleUpload}>Upload</button>
      </div>
      
      <button type="submit">Submit</button>
    </form>
  );
}

export default Table;