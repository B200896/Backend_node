import React, { useState } from 'react';
import { toast } from 'react-toastify';
import axios from "axios";

export function Register() {
    const [name, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');
 

    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            const response = await axios.post('http://localhost:4000/register', {
                name,
                email,
                password
            });

            if (response.status === 200) {
                toast.success("Registration successful", {
                    position: "top-right",
                    autoClose: 3000,
                    theme: "colored"
                });
                
            } else {
                toast.error("Registration failed", {
                    position: "top-right",
                    autoClose: 3000,
                    theme: "colored"
                });
            }
        } catch (error) {
            console.error('Error:', error);
            toast.error("Registration failed", {
                position: "top-right",
                autoClose: 3000,
                theme: "colored"
            });
        }
    };

    return (
        <div className="container">
            <h2>Register Page</h2>
            <form id="registerForm" onSubmit={handleSubmit} method="POST">
                <div>
                    <label htmlFor="name">Username:</label>
                    <input type="text" id="name" name="name" value={name} onChange={(e) => setUsername(e.target.value)} required />
                </div>
                <div>
                    <label htmlFor="email">Email:</label>
                    <input type="email" id="email" name="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                </div>
                <div>
                    <label htmlFor="password">Password:</label>
                    <input type="password" id="password" name="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div>
                <button type="submit">Register</button>
            </form>
        </div>
    );
}
