import { useState } from 'react'
import {Register} from "./Register";
import { ToastContainer } from 'react-toastify';
import './App.css'


function App() {
  

  return (
    <>
    <div>
      <Register />
    </div>
    <ToastContainer/>

    </>
     
  )
}

export default App
