const express = require('express')
const bodyParser=require('body-parser')
const Connectdb = require('./db/connect')
const Product=require('./models/product')
const app=express()
app.use(bodyParser.json())
// const port=3000
app.get('/',(req,res)=>{
    res.send("Express project")
})
app.post('/',async (req,res)=>{
    console.log(req.body);
    const user=new Product(req.body);
    await user.save()
    res.send("Data successfully added")


})

const start = async ()=>{
    await Connectdb()
    
    app.listen(4000,()=>{
        console.log('server start')
    })
}

start()