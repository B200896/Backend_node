const mongoose=require('mongoose');
const productSchema= new mongoose.Schema({
    name:{
        type:String,
        required:true,
    },
    Email:{
        type:String,
        required:[true,"Email must be provided"],
    },
    password:{
        type:String,
        required:[true,"password must be provided"],

    },
    createdAt:{
        type:Date,
        default:Date.now(),
    },

    
})
module.exports=mongoose.model("Product",productSchema);